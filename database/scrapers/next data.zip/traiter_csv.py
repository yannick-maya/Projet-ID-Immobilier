"""
SCRIPT DE LANCEMENT SIMPLIFIÉ - ID IMMOBILIER
Permet de traiter n'importe quel fichier CSV facilement
"""

import sys
import os

# Importer le cleaner depuis le script principal
# (Copier toute la classe IDImmobilierCleanerV2 ici ou l'importer)
from id_immobilier_FINAL import IDImmobilierCleanerV2
import pandas as pd


def traiter_fichier(chemin_fichier, nom_projet='immobilier'):
    """
    Traiter n'importe quel fichier CSV de données immobilières
    
    Args:
        chemin_fichier: Chemin vers le fichier CSV
        nom_projet: Nom pour les exports (défaut: 'immobilier')
    """
    
    print("="*70)
    print(f"🏠 TRAITEMENT DE: {os.path.basename(chemin_fichier)}")
    print("="*70)
    print()
    
    # Vérifier que le fichier existe
    if not os.path.exists(chemin_fichier):
        print(f"❌ ERREUR: Le fichier n'existe pas: {chemin_fichier}")
        return
    
    # Charger
    print(f"📂 Chargement du fichier...")
    df = pd.read_csv(chemin_fichier)
    print(f"   ✓ {len(df)} lignes chargées\n")
    
    # Nettoyer
    cleaner = IDImmobilierCleanerV2()
    df_clean = cleaner.nettoyer_dataset(df)
    
    # Exporter avec nom personnalisé
    if len(df_clean) > 0:
        print("\n" + "="*70)
        print("💾 EXPORTS")
        print("="*70)
        
        # Modifier temporairement le nom de base pour les exports
        cleaner._nom_projet = nom_projet
        
        # Exports
        csv_file = cleaner.exporter_pour_bdd(df_clean, format='csv')
        excel_file = cleaner.exporter_pour_bdd(df_clean, format='excel')
        
        print("\n✅ Traitement terminé !")
        print(f"📊 Fichiers générés:")
        print(f"   - {csv_file}")
        print(f"   - {excel_file}")
    
    return df_clean


# ============================================
# UTILISATION
# ============================================

if __name__ == "__main__":
    
    # MÉTHODE 1 : Ligne de commande
    # Usage: python traiter_csv.py mon_fichier.csv
    if len(sys.argv) > 1:
        fichier = sys.argv[1]
        nom_projet = sys.argv[2] if len(sys.argv) > 2 else 'immobilier'
        traiter_fichier(fichier, nom_projet)
    
    # MÉTHODE 2 : Modifier directement ici
    else:
        # ⚠️ CHANGEZ CES LIGNES ⚠️
        
        # Exemple 1 : Facebook Marketplace
        # traiter_fichier('facebook_lome_terrains_2026.csv', nom_projet='facebook')
        
        # Exemple 2 : ImmoAsk
        # traiter_fichier('immoask_export_fevrier.csv', nom_projet='immoask')
        
        # Exemple 3 : Site d'agence
        # traiter_fichier('agence_xyz_annonces.csv', nom_projet='agence_xyz')
        
        # PAR DÉFAUT (à modifier)
        traiter_fichier(
            '/mnt/user-data/uploads/VOTRE_FICHIER.csv',
            nom_projet='default'
        )
