# 📘 GUIDE SIMPLE : Comment traiter un nouveau fichier CSV

## 🎯 3 MÉTHODES POUR TRAITER VOS NOUVEAUX FICHIERS

---

## ✅ MÉTHODE 1 : LA PLUS SIMPLE (Recommandée)

### Utiliser le script `traiter_csv.py`

**Étape 1** : Ouvrez `traiter_csv.py`

**Étape 2** : Modifiez ces 2 lignes à la fin du fichier :

```python
# LIGNE ~60 (environ)
traiter_fichier(
    '/mnt/user-data/uploads/VOTRE_FICHIER.csv',  # ← Changez le chemin
    nom_projet='facebook'                         # ← Changez le nom
)
```

**Étape 3** : Exécutez
```bash
python traiter_csv.py
```

**C'EST TOUT !** ✅

---

## 🔧 MÉTHODE 2 : Ligne de commande

Si vous préférez la ligne de commande :

```bash
# Syntaxe
python traiter_csv.py FICHIER.csv NOM_PROJET

# Exemples
python traiter_csv.py facebook_mars_2026.csv facebook_mars
python traiter_csv.py immoask_data.csv immoask
python traiter_csv.py agence_xyz.csv agence
```

---

## 🛠️ MÉTHODE 3 : Modifier le script principal directement

### Dans `id_immobilier_FINAL.py`

**Trouvez la fonction `main()` (vers la ligne 430)**

Changez cette ligne :
```python
# AVANT
df = pd.read_csv('/mnt/user-data/uploads/1770856556826_dataset_test_2026-02-12_00-27-35-233.csv')

# APRÈS
df = pd.read_csv('MON_NOUVEAU_FICHIER.csv')
```

---

## 📋 EXEMPLES CONCRETS

### Exemple 1 : Données Facebook d'un autre mois
```python
traiter_fichier(
    'facebook_mars_2026.csv',
    nom_projet='facebook_mars'
)
```

### Exemple 2 : Données ImmoAsk
```python
traiter_fichier(
    'immoask_export_20260212.csv',
    nom_projet='immoask'
)
```

### Exemple 3 : Site d'agence immobilière
```python
traiter_fichier(
    'agence_prestige_annonces.csv',
    nom_projet='prestige'
)
```

### Exemple 4 : Combiner plusieurs sources
```python
# Facebook
df_fb = traiter_fichier('facebook.csv', 'facebook')

# ImmoAsk
df_immo = traiter_fichier('immoask.csv', 'immoask')

# Agence
df_agence = traiter_fichier('agence.csv', 'agence')

# Combiner tous les DataFrames
df_total = pd.concat([df_fb, df_immo, df_agence], ignore_index=True)
```

---

## ⚠️ IMPORTANT : Format du fichier CSV

Votre nouveau fichier CSV doit contenir **AU MINIMUM** ces colonnes :

### Colonnes OBLIGATOIRES (au moins 1 de chaque groupe)

**Groupe 1 - Identifiant** :
- `id` OU
- Toute colonne unique

**Groupe 2 - Titre/Description** :
- `marketplace_listing_title` OU
- `custom_title` OU
- `title` / `titre` / `description`

**Groupe 3 - Prix** :
- `listing_price/amount` OU
- `price` / `prix` / `cout`

**Groupe 4 - Localisation** :
- `location/reverse_geocode/city` OU
- `ville` / `city` / `quartier`

### Colonnes OPTIONNELLES (mais recommandées)
- Surface : `surface`, `surface_m2`, `area`
- Type : `type_bien`, `property_type`
- Photos : `primary_listing_photo/photo_image_url`, `image_url`

---

## 🔄 SI VOS COLONNES ONT DES NOMS DIFFÉRENTS

### Solution rapide : Renommer les colonnes

**Ajoutez ceci JUSTE APRÈS** le chargement du fichier :

```python
# Charger le fichier
df = pd.read_csv('MON_FICHIER.csv')

# Renommer les colonnes pour correspondre au script
df = df.rename(columns={
    'votre_colonne_id': 'id',
    'votre_colonne_titre': 'marketplace_listing_title',
    'votre_colonne_prix': 'listing_price/amount',
    'votre_colonne_ville': 'location/reverse_geocode/city'
})

# Continuer normalement
cleaner = IDImmobilierCleanerV2()
df_clean = cleaner.nettoyer_dataset(df)
```

### Exemple concret - Données ImmoAsk

Si ImmoAsk a ces colonnes :
- `property_id` → ID
- `title` → Titre
- `price_fcfa` → Prix
- `city_name` → Ville

```python
df = pd.read_csv('immoask.csv')

df = df.rename(columns={
    'property_id': 'id',
    'title': 'marketplace_listing_title',
    'price_fcfa': 'listing_price/amount',
    'city_name': 'location/reverse_geocode/city'
})

# Maintenant ça fonctionne !
cleaner = IDImmobilierCleanerV2()
df_clean = cleaner.nettoyer_dataset(df)
```

---

## 📊 VÉRIFIER QUE ÇA FONCTIONNE

Après avoir lancé le script, vous devriez voir :

```
======================================================================
🚀 NETTOYAGE OPTIMISÉ - OBJECTIF 60%+ DE DONNÉES VALIDES
======================================================================
📊 Données initiales: XXX lignes

🔹 ÉTAPE 1 : Extraction des champs essentiels
   ✓ Prix extraits: XX/XXX

🔹 ÉTAPE 2 : Extraction améliorée (surfaces et quartiers)
   ✓ Surfaces extraites: XX/XXX
   ✓ Quartiers identifiés: XX/XXX

🔹 ÉTAPE 3 : Inférence intelligente des surfaces manquantes
   ✓ Surfaces après inférence: XX/XXX (+XX inférées)

🔹 ÉTAPE 4 : Finalisation
   ✓ Tous les champs complétés

🔹 ÉTAPE 5 : Filtrage des données valides
   ✓ Données valides: XX/XXX (XX.X%)

======================================================================
📊 RÉSULTATS FINAUX
======================================================================
✅ OBJECTIF ATTEINT ! XX.X% ≥ 60%  (ou ⚠️ si < 60%)
```

---

## 🎯 RÉSUMÉ ULTRA-SIMPLE

### Pour changer de fichier :

**1 SEULE LIGNE À MODIFIER** :

```python
df = pd.read_csv('NOUVEAU_FICHIER.csv')  # ← ICI
```

**C'EST TOUT !** 🎉

Le reste du code fonctionne automatiquement !

---

## 💡 ASTUCES PRO

### 1. Traiter plusieurs fichiers en boucle

```python
fichiers = [
    'facebook_janvier.csv',
    'facebook_fevrier.csv',
    'facebook_mars.csv'
]

for fichier in fichiers:
    print(f"\n📂 Traitement de {fichier}...")
    df_clean = traiter_fichier(fichier, f'facebook_{fichier[:3]}')
```

### 2. Combiner et dédupliquer

```python
import pandas as pd

# Charger tous les fichiers nettoyés
df1 = pd.read_csv('id_immobilier_optimise_file1.csv')
df2 = pd.read_csv('id_immobilier_optimise_file2.csv')

# Combiner
df_total = pd.concat([df1, df2], ignore_index=True)

# Supprimer les doublons (basé sur id_bien)
df_total = df_total.drop_duplicates(subset='id_bien', keep='first')

# Exporter
df_total.to_csv('base_complete.csv', index=False)
```

### 3. Automatiser avec un cron job (Linux/Mac)

```bash
# Éditer crontab
crontab -e

# Ajouter cette ligne pour exécuter tous les jours à 8h
0 8 * * * cd /chemin/vers/projet && python traiter_csv.py nouveau_scraping.csv
```

---

## ❓ DÉPANNAGE

### Problème : "FileNotFoundError"
**Solution** : Vérifiez le chemin du fichier
```python
import os
print(os.path.exists('MON_FICHIER.csv'))  # Doit afficher True
```

### Problème : "KeyError" pour une colonne
**Solution** : Renommez vos colonnes (voir section ci-dessus)

### Problème : Taux de validité très bas (< 30%)
**Solution** : Vos données sont peut-être dans un format différent
- Vérifiez les colonnes disponibles : `print(df.columns)`
- Adaptez les patterns d'extraction si nécessaire

---

## 📞 BESOIN D'AIDE ?

Si vous avez un nouveau fichier avec un format très différent :
1. Partagez les premières lignes du CSV
2. Indiquez les noms des colonnes
3. Je vous aiderai à adapter le script !

---

**Bonne chance avec vos nouveaux fichiers ! 🚀**
